#!/bin/sh
/opt/python-3.6/bin/python3.6 maxent_classify.py $@