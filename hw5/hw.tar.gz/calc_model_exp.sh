#!/bin/sh
/opt/python-3.6/bin/python3.6 calc_model_exp.py $@