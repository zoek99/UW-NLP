#!/bin/sh
python3 build_dt.py $@